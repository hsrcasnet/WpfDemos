﻿namespace DelegateCommandWith.ViewModels
{
    public interface IDialogService
    {
        void ShowMessageBox(string message);
    }
}