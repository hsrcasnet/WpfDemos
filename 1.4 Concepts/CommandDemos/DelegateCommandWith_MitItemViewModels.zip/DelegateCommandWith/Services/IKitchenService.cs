﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DelegateCommandWith.Model;

namespace DelegateCommandWith.Services
{
    public interface IKitchenService
    {
        Task<MealDto> PrepareMeal(int numberOfPersons);
        
        Task<IEnumerable<MealDto>> PrepareMeals(int numberOfPersons);
        void DeleteMeal(int id);
    }
}