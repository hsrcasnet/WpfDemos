﻿using System;
using System.Collections.Generic;
using System.Windows.Markup;
using System.Windows;
using System.ComponentModel;
using System.Globalization;
using System.Windows.Data;
using System.Resources;
using System.Threading;
using System.Reflection;
using System.Diagnostics;
using System.Windows.Controls;
using System.Windows.Media;
using System.Linq;
using System.Configuration;

namespace Westwind.Wpf.Controls
{

    /// <summary>
    /// The Res markup extension returns localized values from 
    /// 
    /// To use:
    ///   * Make sure you register the namespace of this extension in the document header
    ///     xmlns:local="clr-namespace:Westwind.Wpf.Controls"
    ///   * Embed the extension as follows:
    ///     Content="{local:Res Id=HelloWorld,Default=Hello World}"   // gets from Resources
    ///     Content="{local:Res Id=HelloWorld,Default=Hello World,ResourceSet=WpfLocalizationResx.ResxResource,Format=You said: \{0\}"    
    ///     in addition you can pass Format (string.Format() string) and Convert (WPF Type Converter) as parameters
    ///     
    /// This extension requires that you have a Properties.Resources object defined
    /// in order to find the default resource set, and assembly.
    /// 
    /// NOTE:
    /// THIS MARKUP EXTENSION MUST BE PLACED IN THE SAME PROJECT AS THE RESOURCES YOU ARE TRYING
    /// TO LOAD DUE TO ISSUES WITH GETTING A REFERENCE TO THE RESOURCE ASSEMBLY IN THE DESIGNER.
    /// IT'LL WORK FINE AT RUNTIME IN A SEPARATE ASSEMBLY BUT THE DESIGNER WILL FAIL TO RENDER
    /// UNLESS THE EXTENSION IS IN THE SAME ASSEMBLY AS THE RESOURCES.
    /// 
    /// I've been unable to find a solution how to get access to the default assembly via code
    /// as the designer doesn't load App.Xaml nor provides a normal execution context. It also
    /// doesn't provide Parent properties on controls. If you know of a way to get a reference
    /// to the startup assembly or even the parent page from a control instance please contact me.    
    /// </summary>
    [MarkupExtensionReturnType(typeof(object)), Localizability(LocalizationCategory.NeverLocalize)]
    public class ResExtension : MarkupExtension
    {

        static ResExtension()
        {
            // *** YOU CAN OVERRIDE THE RESOURCE MANAGER USED HERE            
            // *** You can also do this in App.xaml.cs but the designer will not find it
            //     so this is where any overrides should go
            //     If you use the default assembly and Properties.Resources.ResourceManager
            //     the following is not necessary
            //ResExtension.InitializeResExtension(Assembly.GetExecutingAssembly(),
            //                                    WpfClickOnce.Properties.Resources.ResourceManager);                                                
        }

        /// <summary>
        /// Contains static settings for the ResourceAssembly and default Resource
        /// Manager. Looks in app.config for AppSettings DefaultResourceAssembly
        /// 
        /// </summary>
        public static ResExtensionSettings Settings = new ResExtensionSettings();

        ///// <summary>
        ///// Type in the assembly where where resources are to be loaded from
        ///// 
        ///// Here we use the Resources property since we're in WPF application
        ///// project. If you extract this into a sepearte assembly though you'll
        ///// need to explicitly assign a type on application startup.
        ///// </summary>
        ////protected static Type ResourceType = null;
        //internal static Assembly DefaultResourceAssembly = null;

        /// <summary>
        /// Optional default ResourceManager
        /// </summary>
        internal static ResourceManager DefaultResourceManager = null;


        ///// <summary>
        ///// Initializes the resource manager so that we can find resources.
        ///// Specify a default resource manager that can be accessed without 
        ///// ResourceSet prefix
        ///// </summary>
        //public static void InitializeResExtension(Assembly resourceAssembly, ResourceManager manager)
        //{
        //    DefaultResourceManager = manager;
        //    DefaultResourceAssembly = resourceAssembly; 
        //}
 
        /// <summary>
        /// Caches the depending target object
        /// </summary>
        DependencyObject _targetObject;

        /// <summary>
        /// Caches the depending target property
        /// </summary>
        DependencyProperty _targetProperty;

        /// <summary>
        /// Caches the resolved default type converter
        /// </summary>
        TypeConverter _typeConverter;

        /// <summary>
        /// Cache the ServiceProvider
        /// </summary>
        private IServiceProvider _serviceProvider;

        public ResExtension()            
        {
        }

        /// <summary>
        /// Allow calling the extension with a default parameter (id).
        /// Content="{local:Res HelloWorld}"
        /// </summary>
        /// <param name="param">The key that specifies a localization </param>
        public ResExtension(string id) : this()
        {
            Id = id as string;
        }


        /// <summary>
        /// The ResourceId to retrieve
        /// </summary>
        /// <value>The key.</value>
        [ConstructorArgument("Id")]
        public string Id { get; set; }


        /// <summary>
        /// A default value that is returned when the the resource
        /// cannot be resolved. Also returned in the designer if
        /// there are no resources available.
        /// </summary>
        /// <value>The default value.</value>
        [ConstructorArgument("Default")]
        public object Default { get; set; }

        /// <summary>
        /// Optional Resource Set Name. If not provided it's
        /// assumed you want to access the global Resources
        /// resource set in Properties.Resources
        /// </summary>
        [ConstructorArgument("ResourceSet")]
        public string ResourceSet { get; set; }

        /// <summary>
        /// A string.Format format string that is applied.
        /// Note when provided the result value is always 
        /// converted into a string.
        /// </summary>
        /// <value>The format.</value>
        [ConstructorArgument("Format")]
        public string Format { get; set; }
        
        /// <summary>
        /// Allows to specify a custom Value Converter using standard WPF syntax.
        /// </summary>
        /// <value>The converter.</value>
        [ConstructorArgument("Converter")]
        public IValueConverter Converter { get; set; }


        /// <summary>
        /// The core method to provide a localized value.
        /// 
        /// Note the value can also be a non-string value to set non-string properties
        /// </summary>
        /// <param name="serviceProvider"></param>
        /// <returns></returns>
        public override object ProvideValue(IServiceProvider serviceProvider)
        {
            // Resolve the depending object and property
            if (_targetObject == null)
            {
                var targetService = (IProvideValueTarget)serviceProvider.GetService(typeof(IProvideValueTarget));
                _targetObject = targetService.TargetObject as DependencyObject;
                _targetProperty = targetService.TargetProperty as DependencyProperty;
                _typeConverter = TypeDescriptor.GetConverter(_targetProperty.PropertyType);

            }
            _serviceProvider = serviceProvider;

            return ProvideValueInternal();
        }

        /// <summary>
        /// Retrieves a resource manager for the appropriate ResourceSet
        /// By default the 'global' Resource
        /// </summary>
        /// <param name="resourceSet"></param>
        /// <returns></returns>
        private ResourceManager GetResourceManager(string resourceSet)
        {
            // At design time try to get the default assembly
            if (ResExtension.Settings.DefaultResourceAssembly == null)
                ResExtension.Settings.FindDefaultResourceAssembly();

            if ( string.IsNullOrEmpty(resourceSet) )                
                return DefaultResourceManager ?? null;
            
            if (ResExtension.Settings.ResourceManagers.ContainsKey(resourceSet))                
                return ResExtension.Settings.ResourceManagers[resourceSet];

            ResourceManager man = new ResourceManager(resourceSet, ResExtension.Settings.DefaultResourceAssembly);
            ResExtension.Settings.ResourceManagers.Add(resourceSet, man);
            return man;
        }

        /// <summary>
        /// Internal value retrieval
        /// </summary>
        /// <returns></returns>
        private object ProvideValueInternal()
        {
            // Get a cached resource manager for this resource set
            ResourceManager resMan = this.GetResourceManager(this.ResourceSet);
            object localized = null;

            // Get the localized value 
            if (resMan != null)
            {
                try
                {
                    localized = resMan.GetObject(this.Id);
                }
                catch { }
            }            
   
            // If the value is null, use the Default value if available
            if (localized == null && this.Default != null)
                localized = this.Default;

            

            // fail type conversions silently and write to trace output
            try
            {
                // Convert if a type converter is availalbe
                if (localized != null && this.Converter == null &&
                    _typeConverter != null && _typeConverter.CanConvertFrom(localized.GetType()))
                    localized = _typeConverter.ConvertFrom(localized);

                // Apply a type converter if one was specified
                if (Converter != null)
                    localized = this.Converter.Convert(localized, _targetProperty.PropertyType, null, CultureInfo.CurrentCulture);
            }
            catch(Exception ex)
            {
                Trace.WriteLine(string.Format("ResExtension Type conversion failed. Id: {0}, Error: {1}", Id, ex.Message));
                localized = null;
            }

            // If no fallback value is available, return the key
            if (localized == null)
            {
                if (_targetProperty != null && _targetProperty.PropertyType == typeof(string))               
                    // Return the key surrounded by question marks for string type properties
                    localized = string.Concat("?", Id, "?");                
                else                
                    // Return the UnsetValue for all other types of dependency properties
                    return DependencyProperty.UnsetValue;                
            }            

            // Format if a format string was provided
            if (this.Format != null)            
                localized = string.Format(CultureInfo.CurrentUICulture, this.Format, localized);
           
            return localized;
        }



    }

    /// <summary>
    /// This class holds static configuration values that should
    /// be set once (or be auto-loaded once) for the application
    /// 
    /// This object becomes a static property on the ResExtension
    /// instance.
    /// </summary>
    public class ResExtensionSettings
    {
        /// <summary>
        /// The default resource manager used.
        /// </summary>
        public ResourceManager DefaultResourceManager { get; set; }

        /// <summary>
        /// The Assembly from which resources are loaded
        /// </summary>
        public Assembly DefaultResourceAssembly { get; set; }

        /// <summary>
        /// Cached ResourceManagers for each ResourceSet supported requested.       
        /// </summary>
        internal Dictionary<string, ResourceManager> ResourceManagers = new Dictionary<string, ResourceManager>();
        

        public ResExtensionSettings()
        {
            // Try to load from config
            //LoadFromConfig();
        }

        /// <summary>
        /// Tries to load the assembly and resource manager 
        /// based on an assembly name in a configuration file
        /// </summary>
        public bool LoadFromConfig()
        {
            string assemblyName = ConfigurationManager.AppSettings["DefaultResourceAssembly"];
            if (assemblyName == null)
                return false;

            Assembly assembly = AppDomain.CurrentDomain.GetAssemblies()
                                                         .Where(ass => ass.GetName().Name == assemblyName || ass.FullName == assemblyName)
                                                         .FirstOrDefault();
            if (assembly == null)
                return false;

            // Search for Properties.Resources in the Exported Types (has to be public!)
            Type ResType = assembly.GetExportedTypes().Where(type => type.FullName.Contains(".Properties.Resources")).FirstOrDefault();
            if (ResType == null)
                return false;

            ResourceManager resMan = ResType.GetProperty("ResourceManager").GetValue(ResType, null) as ResourceManager;

            this.DefaultResourceAssembly = assembly;
            this.DefaultResourceManager = resMan;

            return true;
        }

        /// <summary>
        /// This method tries to find the strongly typed Resource class in a project
        /// so the designer works properly.
        /// 
        /// THIS CODE ASSUMES THE MAKKUP EXTENSION RUNS IN THE SAME ASSEMBLY THAT
        /// ALSO CONTAINS RESOURCES. THIS IS DONE FOR THE DESIGNER ONLY. I HAVE
        /// NOT BEEN ABLE TO FIGURE OUT A WAY TO GET A REFERENCE TO THE STARTUP
        /// ASSEMBLY IN THE DESIGNER. IF YOU FIGURE OUT A WAY PLEASE CONTACT ME.
        /// </summary>
        /// <returns></returns>
        internal bool FindDefaultResourceAssembly()
        {
            // Assume the Document we're called is in the same assembly as resources
            Assembly ass = Assembly.GetExecutingAssembly();

            // Search for Properties.Resources in the Exported Types (has to be public!)
            Type ResType = ass.GetExportedTypes().Where(type => type.FullName.Contains(".Properties.Resources")).FirstOrDefault();
            if (ResType == null)
                return false;

            ResourceManager resMan = ResType.GetProperty("ResourceManager").GetValue(ResType, null) as ResourceManager;

            this.DefaultResourceAssembly = ass;
            this.DefaultResourceManager = resMan;

            return true;
        }
    }
}
